# Noor

🌍 **Noor** is a live age calculator command-line tool.

It shows how long you have lived on Earth in:
- Years
- Days
- Hours
- Minutes
- Seconds (updates live)

## Install

```bash
pip install noor


noor
Enter your date of birth in this format:
Copy code

YYYY-MM-DD
Press Ctrl + C to exit.
Works On
Linux
macOS
Windows
Termux (Android)


